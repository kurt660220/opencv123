import numpy as np
import cv2

me = cv2.imread('Lena.jpg')
print(me.shape)

rows, cols = me.shape[:2]
print(rows,cols)

pts1 = np.float32([[0, 0], [315, 0], [0, 315], [315, 315]])
pts2 = np.float32([[70, 100], [245, 50], [0, 315], [315, 315]]) 

M = cv2.getPerspectiveTransform(pts1,pts2) 
#注意矩陣大小跟之前的不一樣
dst = cv2.warpPerspective(me, M, (cols,rows))

cv2.imshow("img",me)
cv2.imshow("dst",dst)
cv2.waitKey()
cv2.destroyAllWindows()
