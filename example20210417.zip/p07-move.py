import numpy as np
import cv2

lena = cv2.imread('Lena.jpg')
print(lena.shape)
cv2.imshow('lena', lena)
rows, cols = lena.shape[0:2] 
M = np.float32([[1, 0, 100], [0, 1, 100]])
move = cv2.warpAffine(lena,M,(cols,rows))
cv2.imshow('move', move)

M = np.float32([[0.8, 0, -20], [0, 3, -20]])
resize = cv2.warpAffine(lena,M,(cols,rows))
cv2.imshow('resize', resize)

M = np.float32([[0, 1, 0], [1, 0, 0]])
r1 = cv2.warpAffine(lena,M,(rows,cols))
cv2.imshow('r1', r1)

M = np.float32([[-1, 0, cols], [0, 1, 0]])
r2 = cv2.warpAffine(lena,M,(cols,rows))
cv2.imshow('r2', r2)


cv2.waitKey()
cv2.destroyAllWindows()