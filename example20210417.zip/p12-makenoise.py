import numpy as np
import cv2

img = cv2.imread('Lena.jpg')
cv2.imshow('Lena', img)
noise = np.random.randint(0, 255, size=img.shape, dtype=np.uint8)
t, noise = cv2.threshold(noise, 240, 255, cv2.THRESH_TOZERO)
noiseLena = cv2.add(img, noise)
cv2.imshow('noise', noiseLena)
Blur3 = cv2.blur(noiseLena, (7, 7))
cv2.imshow("Blur3", Blur3)
GaussianBlur = cv2.GaussianBlur(noiseLena, (5, 5), 0)
cv2.imshow("GaussianBlur", GaussianBlur)
medianBlur = cv2.medianBlur(noiseLena, 5)
cv2.imshow("medianBlur", medianBlur)
r4 = cv2.bilateralFilter(noiseLena, 15, 160, 160)
cv2.imshow("bilateralFilter",r4)
cv2.waitKey()
cv2.destroyAllWindows()