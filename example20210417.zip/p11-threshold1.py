import cv2
import numpy as np

img = cv2.imread('example2.jpg', 0)
print('cv2.THRESH_BINARY:', cv2.THRESH_BINARY)
print('cv2.THRESH_OTSU:', cv2.THRESH_OTSU)
t1,thd = cv2.threshold(img,127,255,cv2.THRESH_BINARY)
t2,otsu = cv2.threshold(img,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
cv2.imshow("img",img)
cv2.imshow("thd",thd)
cv2.imshow("otus",otsu)
print('t1:', t1)
print('t2:', t2)
cv2.waitKey()
cv2.destroyAllWindows()
