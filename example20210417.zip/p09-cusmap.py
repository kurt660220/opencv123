import numpy as np
import cv2

me = cv2.imread('Lena.jpg')
print(me.shape)

rows, cols, ch = me.shape
p1 = np.float32([[10, 10], [cols-150, 0], [0, rows-10]])

p2 = np.float32([[0, rows*0.33], [cols*0.85, rows*0.25], [cols*0.15, rows*0.7]])

M = cv2.getAffineTransform(p1, p2)
print("M: ", M)
dst = cv2.warpAffine(me, M, (cols, rows))
cv2.imshow("origianl", me)
cv2.imshow("result", dst)

cv2.waitKey()
cv2.destroyAllWindows()
