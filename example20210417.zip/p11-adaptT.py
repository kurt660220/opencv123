import cv2

img = cv2.imread("book.jpg", 0)
h, w = img.shape[:2]
testimg = cv2.resize(img, (w//2, h//2))
t1, thd = cv2.threshold(testimg, 127, 255, cv2.THRESH_BINARY) 

athdMEAN = cv2.adaptiveThreshold(testimg, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 5, 3) 

athdGAUS = cv2.adaptiveThreshold(testimg, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 5, 3)

cv2.imshow("img",testimg)
cv2.imshow("thd",thd)
cv2.imshow("athdMEAN",athdMEAN)
cv2.imshow("athdGAUS",athdGAUS)
cv2.waitKey()
cv2.destroyAllWindows()
